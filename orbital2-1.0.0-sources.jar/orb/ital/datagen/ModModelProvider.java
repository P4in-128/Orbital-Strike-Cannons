package orb.ital.datagen;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.minecraft.client.data.models.BlockModelGenerators;
import net.minecraft.client.data.models.ItemModelGenerators;
import net.minecraft.client.data.models.model.ModelTemplates;
import orb.ital.block.ModBlocks;
import orb.ital.item.ModItem;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricPackOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(BlockModelGenerators blockModelGenerators) {









    }

    @Override
    public void generateItemModels(ItemModelGenerators itemModelGenerators) {
       itemModelGenerators.generateFishingRod(ModItem.STAB);
        itemModelGenerators.generateFishingRod(ModItem.NUKE);

    }
}
